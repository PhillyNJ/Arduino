﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Com
{
    public class USBDeviceInfo
    {
        public USBDeviceInfo(string deviceID, string pnpDeviceID, string description, string name)
        {
            this.DeviceID = deviceID;
            this.PnpDeviceID = pnpDeviceID;
            this.Description = description;
            this.Name = name;
        }
        public String DeviceID { get; private set; }
        public String PnpDeviceID { get; private set; }
        public String Description { get; private set; }
        public String Name { get; private set; }

    }
}
