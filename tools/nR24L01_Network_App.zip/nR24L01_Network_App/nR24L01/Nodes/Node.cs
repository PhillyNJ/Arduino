﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nR24L01.Nodes
{
    public class Node
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Id
        {
            get
            {

                return this.Name == null ? 0 : Convert.ToInt32(this.Name);
            }
        }
        public String ParentName { get; set; }
        public String Name { get; set; }
        public int mouseX { get; set; }
        public int mouseY { get; set; }
        public PictureBox Imagebox { get; set; }
        Action RefreshEvent;
        Action Reconnect;
        private bool drag;
        public PictureBox GetNode
        {
            get
            {
                return this.Imagebox;
            }
        }

        public Node(String name, int x, int y, String imagePath, Action refresh, Action reconnect)
        {

            this.X = x;
            this.Y = y;
            this.Name = name;
            this.ParentName = "0"; // default
            this.Imagebox = new PictureBox
            {
                Name = name,
                Size = new Size(55, 75),
                Location = new Point(x, y),
                Image = Image.FromFile(Application.StartupPath + "/img/" + imagePath),

            };
            ToolTip tt = new ToolTip();
            tt.SetToolTip(this.Imagebox, name);

            this.Imagebox.MouseDown += new MouseEventHandler(nodeDownEvent);
            this.Imagebox.MouseMove += new MouseEventHandler(nodeMoveEvent);
            this.Imagebox.MouseUp += new MouseEventHandler(nodeUpEvent);
            RefreshEvent = refresh;
            Reconnect = reconnect;
            Font drawFont = new Font("Arial", 8);
            this.Imagebox.Paint += new PaintEventHandler((sender, e) =>
            {
                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

                String text = String.Empty;

                if (this.Name == "0")
                {
                    text = "Base Node";
                }
                else {

                    text = $"Node: {this.Name}";
                }

                SizeF textSize = e.Graphics.MeasureString(text, drawFont);
                PointF locationToDraw = new PointF();
                locationToDraw.X = (this.Imagebox.Width / 2 ) - (textSize.Width / 2);
                locationToDraw.Y = (this.Imagebox.Height / 2) - (textSize.Height / 2) + 20;

                e.Graphics.DrawString(text, drawFont, Brushes.White, locationToDraw);
            });
        }

        private void nodeDownEvent(object sender, MouseEventArgs e)
        {
            // Get original position of cursor on mousedown
            mouseX = e.X;
            mouseY = e.Y;
            drag = true;
            this.RefreshEvent();

        }
        private void nodeUpEvent(object sender, MouseEventArgs e)
        {
            drag = false;
        }
        private void nodeMoveEvent(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                PictureBox pb = (PictureBox)sender;
                // Get new position of picture
                pb.Top += e.Y - mouseY;
                pb.Left += e.X - mouseX;
                pb.BringToFront();
                this.RefreshEvent();
                this.Reconnect();
            }
        }
    }

    public enum Node_T
    {

        BASE = 0,
        RELAY = 1,
        TRANSMITTER = 3

    }
}
