﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO.Ports;
using System.Management;
using Com;
using nR24L01.Nodes;
using System.Threading;

namespace nR24L01
{
    public delegate void RenderNodeDelegate(String name);
    public delegate void PacketCountDelegate(bool valid);
    public delegate void UpdateUIDelegate(String name);

    public partial class Form1 : Form
    {
        private const String TRANSMITTER = "transmitter_app_50.bmp";
        private const String BASENODE = "radar_app_50.bmp";
        private int packets;
        private int droppedPackets;
        private Action _refreshDelegate;
        private Action _reConnectNodeDelegate;              
        
        private String _comPort { get; set; }
        private SerialPort _serPort { get; set; }
        private List<Node> Nodes = new List<Node>();
        private Graphics g;

        public Form1()
        {
            InitializeComponent();
            this.InitCom();
            this._refreshDelegate = refreshLines;
            this._reConnectNodeDelegate = reconnect;
        
            // add the base node
            Node baseNode = new Node("0", this.Width / 2, this.Height / 2, BASENODE, _refreshDelegate, _reConnectNodeDelegate);
            this.Controls.Add(baseNode.GetNode);
            Nodes.Add(baseNode);

            this.status.Focus();
        }

        private void getComPorts()
        {
            updateStatus("getting com ports...");
            String[] ports = SerialPort.GetPortNames();
            List<USBDeviceInfo> devices = this.getUSBDevices();
            upDateUi("Scanning ports...");
            foreach (COMPortInfo comPort in COMPortInfo.GetCOMPortsInfo())
            {
                String prtDis = String.Format("{0} {1}", comPort.Name, comPort.Description);

                upDateUi(String.Format("Found {0} ", prtDis));
                this.addComMenuItem(prtDis, String.Format("menu{0}", comPort.Name), comPort.Name);
                updateStatus(String.Format("Adding {0} ", prtDis));
            }
            
        }
        private void updateStatus(String text) {

            this.statusLabel.Text = text;
            upDateUi(text);
        }
        private void renderNodeDelegate(String name) {
            renderNode(name);
        }

        private void upDateUi(String str) {

            this.txtLog.Text += $"{str}{Environment.NewLine}";
            this.txtLog.SelectionStart = this.txtLog.TextLength;
            this.txtLog.ScrollToCaret();
        }
              
        private void packetCountHandler(bool valid) {

            if (valid)
            {                
                this.packets = this.packets + 1;
            }
            else
            {
                this.droppedPackets = this.droppedPackets + 1;
            }            

            this.lblDroppedPackets.Text = $"Dropped Packets: {this.droppedPackets}";
            this.lblPackets.Text = $"Packets: {this.packets}";
        }

        private void renderNode(String name) {

            updateStatus($"Incoming data from {name}");
            var exists = this.Nodes.Where(x => x.Name == name).Any();
            int id = Convert.ToInt32(name);
            if (exists) {
                updateStatus($"Data received from node {name}");
                return;
            }
         
            Node nd = createNode(name);
            // (n * 5) + 2,3,4,5,6 = id;
            int hops = 0;
            if (id > 50)
            {
                hops = 2;
            }
            else if (id < 50 && id > 6)
            {
                hops = 1;
            }

            for (int i = 0; i < hops; i++)
            {
                // find parent
                for (int x = 2; x < 7; x++)
                {
                    var val = id - x;
                    if (val % 5 == 0)
                    {
                        x = 10; // end check
                        id = val / 5;
                        nd.ParentName = id.ToString();
                        var ext = this.Nodes.Where(z => z.Name == id.ToString()).Any();
                        if (!ext)
                        {
                            nd = createNode(id.ToString());
                        }
                        else
                        {
                            hops--;
                        }
                    }
                }
            }
            refreshLines(); // clear any connections and redraw
            reconnect();           
           
            updateStatus($"Data received from node {name}");
           
        }

        private Node createNode(String name)
        {
            Node trans = new Node(name, Convert.ToInt32(name), Convert.ToInt32(name), TRANSMITTER, _refreshDelegate, _reConnectNodeDelegate);
            this.Controls.Add(trans.GetNode);
            Nodes.Add(trans);
            return trans;
        }
        private void addComMenuItem(String text, String name, String comPort)
        {
            ToolStripMenuItem newMenu = new System.Windows.Forms.ToolStripMenuItem();
            newMenu.Name = name;
            newMenu.Text = text;
            newMenu.Tag = comPort;

            this.menuConnect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                newMenu
            });
            if (comPort != "disconnect")
            {
                newMenu.Click += comMenuClick;
            }
            else {

                newMenu.Click += disconnectSerial;
            }
            
        }


        private void disconnectSerial(object sender, EventArgs e) {
            this.menuConnect.Text = "Connect";
            if (_serPort != null && _serPort.IsOpen)
            {
                _serPort.Close();
            }
            ToolStripMenuItem disconnect = new ToolStripMenuItem();
            foreach (ToolStripMenuItem it in this.menuConnect.DropDownItems)
            {
                if (it.Tag.ToString() != "disconnect") 
                {
                    it.Enabled = true;
                }
                else {
                    disconnect = it;
                }

            }
            this.menuConnect.DropDownItems.Remove(disconnect);
            upDateUi("Disconnected");
        }

        private void comMenuClick(object sender, EventArgs e)
        {
            ToolStripMenuItem item = (ToolStripMenuItem)sender;
            this._comPort = (String)item.Tag;
            upDateUi($"Connecting to {this._comPort}");
            updateStatus(String.Format("Connecting to  {0} ", this._comPort));
            foreach (ToolStripMenuItem it in this.menuConnect.DropDownItems) {
                if (!String.IsNullOrEmpty(it.Tag.ToString())) {
                    it.Enabled = false;
                }
               
            }
            if (!String.IsNullOrEmpty(this._comPort))
            {
                this.InitSerialPort();
                this.addComMenuItem("Disconnect", "disconnect", "disconnect");
                this.menuConnect.Text = "Disconnect";
            }
            else
            {
                upDateUi("No com port detected ");
            }

        }
        private List<USBDeviceInfo> getUSBDevices()
        {
            List<USBDeviceInfo> devices = new List<USBDeviceInfo>();

            var searcher = new ManagementObjectSearcher("root\\cimv2", @"Select * From Win32_USBHub");

            foreach (var device in searcher.Get())
            {
                devices.Add(new USBDeviceInfo(
                (String)device.GetPropertyValue("DeviceID"),
                (String)device.GetPropertyValue("PNPDeviceID"),
                (String)device.GetPropertyValue("Description"),
                (String)device.GetPropertyValue("Name")
                ));

            }
            return devices;
        }
        private void InitCom()
        {
            this.getComPorts();

        }

        private void InitSerialPort()
        {
            try
            {
                this._serPort = new SerialPort(); // initialize the serial port object
                this._serPort.BaudRate = 115200;
                this._serPort.Parity = Parity.None;
                this._serPort.DataBits = 8;
                this._serPort.StopBits = StopBits.One;
                this._serPort.ReadTimeout = 11500;
                this._serPort.WriteTimeout = 500;
                this._serPort.Handshake = Handshake.None;
                // set the handler to listen for data over the com port
                this._serPort.PortName = _comPort;
                this._serPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                upDateUi($"Connected to {this._comPort}");

                upDateUi($"nRF24l01 - Connected to {this._comPort} at {this._serPort.BaudRate}");
               
                if (!_serPort.IsOpen)
                {
                    _serPort.Open();
                }
            }
            catch (Exception ex)
            {
                upDateUi("Failed to connected to com port");
                upDateUi($"Error: {ex.Message}");
            }

        }

       
        private void DataReceivedHandler(object sender,  SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            try
            {               
                string indata = sp.ReadExisting();
                
                /*  Console.Write(indata);
                    [0]: "255"  start token
                    [1]: "5"    node id
                    [2]: "7"    end token
                    [3]: "22"   data low byte
                    [4]: "0"    data high byte
                    [5]: "100"  data low byte
                    [6]: "0"    data high byte
                    [7]: "206"  data low byte
                    [8]: "255"  data high byte
                    [9]: "133"  checksum low byte
                    [10]: "1"
                    [11]: "0"
                    [12]: "0"   check sum high byte
                    [13]: ""
                    [14]:

                 */
                string[] dataArray = indata.Split('\n');

                if (dataArray.Length > 13)
                {
                    byte[] checkSumArray = { Convert.ToByte(dataArray[9]), Convert.ToByte(dataArray[10]), Convert.ToByte(dataArray[11]), Convert.ToByte(dataArray[12]) };
                    byte[] data3Array =     { Convert.ToByte(dataArray[7]), Convert.ToByte(dataArray[8]) };
                    byte[] data2Array = { Convert.ToByte(dataArray[5]), Convert.ToByte(dataArray[6]) };
                    byte[] data1Array = { Convert.ToByte(dataArray[3]), Convert.ToByte(dataArray[4]) };

                    Packet pck = new Packet
                    {
                        StartToken = Convert.ToInt32(dataArray[0]),
                        Id = Convert.ToInt32(dataArray[1]),
                        EndToken = Convert.ToInt32(dataArray[2]),
                        Data =  BitConverter.ToInt16(data1Array, 0),
                        Data2 = BitConverter.ToInt16(data2Array, 0),
                        Data3 = BitConverter.ToInt16(data3Array, 0),
                        CheckSum = BitConverter.ToInt32(checkSumArray, 0)
                };

                int checksum = pck.StartToken + pck.EndToken + pck.Id + pck.Data + pck.Data2;

                Console.Write("Data: " + pck.Data + Environment.NewLine);
                Console.Write("Data2: " + pck.Data2 + Environment.NewLine);
                Console.Write("Data3: " + pck.Data3 + Environment.NewLine);
                Console.Write("Checksum: " + pck.CheckSum + Environment.NewLine);
                Console.Write("Calc Checksum: " + checksum + Environment.NewLine);   

                // validate the check sum                                
                if (checksum == pck.CheckSum && pck.StartToken == 255 && pck.EndToken == 7 && pck.Id > 0 && pck.Id < 252)
                {                        
                     RenderNodeDelegate d = new RenderNodeDelegate(renderNode);
                     this.Invoke(d, new object[] { pck.Id.ToString() });

                     PacketCountDelegate pd = new PacketCountDelegate(packetCountHandler);
                     this.Invoke(pd, new object[] { true });
                 }  else {     
                                      
                    PacketCountDelegate pd = new PacketCountDelegate(packetCountHandler);
                    this.Invoke(pd, new object[] { false });

                } 
            }

               
            }
            catch (Exception ex)
            {
                PacketCountDelegate pd = new PacketCountDelegate(packetCountHandler);
                this.Invoke(pd, new object[] { false });

                UpdateUIDelegate up = new UpdateUIDelegate(upDateUi);
                this.Invoke(up, new object[] { ex.ToString() });

            }
            sp.DiscardInBuffer(); // clear any incoming data until we update the UI

        }        

        private int combine(byte b1, byte b2)
        {
            return b1 << 8 | b2;            
        }
               
        private void refreshLines()
        {
            g.Clear(Color.Black); //This is our backcolor
        }
        private void reconnect()
        {
            // nodes 2-6 
            // 7 - 49
            // 50 - 251
            Pen pen = new Pen(Color.FromArgb(255, 255, 255, 255));
            foreach (var nd in this.Nodes.OrderBy(x => x.Id))
            {
                if (nd.Id > 0)
                {
                    var parent = this.Nodes.Where(x => x.Name == nd.ParentName).First();
                    if (parent != null)
                    {
                        g.DrawLine(pen, parent.Imagebox.Location.X + 25, parent.Imagebox.Location.Y, nd.Imagebox.Location.X, nd.Imagebox.Location.Y + 25);
                    }
                }
            }

        }
       

        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            this.ActiveControl = this.groupBox1;
         }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            disconnectSerial(new object(), new EventArgs());
            this.txtLog.Text = String.Empty;
            var nodesToRemove = (from n in this.Nodes.Where(x => x.Name != "0")
                                 select n.Imagebox).ToList();
           
            if (nodesToRemove != null & nodesToRemove.Any()) {

                foreach (var nd in nodesToRemove) {
                    this.Controls.Remove(nd);
                    this.Nodes.RemoveAll(x => x.Imagebox.Name == nd.Name);
                }
               
            }
            this.menuConnect.DropDownItems.Clear();
            this.getComPorts(); // gets new list
            refreshLines(); // clear any connections and redraw
        }

        private void clearLogsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtLog.Text = String.Empty;
        }

        private void clearPackeCountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.packets = 0;
            this.droppedPackets = 0;
            this.lblDroppedPackets.Text = $"Dropped Packets: {this.droppedPackets}";
            this.lblPackets.Text = $"Packets: {this.packets}";
        }
    }
}
